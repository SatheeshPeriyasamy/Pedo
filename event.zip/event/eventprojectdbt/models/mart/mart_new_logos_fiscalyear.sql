WITH first_purchase AS (
    SELECT 
        CUSTOMER_ID,
        MIN(PAYMENT_MONTH) AS first_purchase_date
    FROM {{ ref('stg_event_booking_transactions') }}
    GROUP BY CUSTOMER_ID
)
SELECT 
    CUSTOMER_ID,
    TO_CHAR(first_purchase_date, 'YYYY') AS fiscal_year
FROM first_purchase