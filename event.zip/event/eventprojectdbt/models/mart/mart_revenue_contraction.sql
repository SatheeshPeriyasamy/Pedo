WITH revenue_contraction AS (
    SELECT 
        CUSTOMER_ID,
        PAYMENT_MONTH,
        REVENUE,
        LAG(REVENUE) OVER (PARTITION BY CUSTOMER_ID ORDER BY PAYMENT_MONTH) AS prev_revenue
    FROM {{ ref('stg_event_booking_transactions') }}
)
SELECT 
    CUSTOMER_ID,
    PAYMENT_MONTH,
    prev_revenue - REVENUE AS revenue_lost
FROM revenue_contraction
WHERE prev_revenue > REVENUE