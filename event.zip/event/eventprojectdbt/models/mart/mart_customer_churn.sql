WITH transactions AS (
    SELECT DISTINCT CUSTOMER_ID, PAYMENT_MONTH 
    FROM {{ ref('stg_event_booking_transactions') }}
),
customer_activity AS (
    SELECT 
        CUSTOMER_ID,
        PAYMENT_MONTH,
        LAG(PAYMENT_MONTH) OVER (PARTITION BY CUSTOMER_ID ORDER BY PAYMENT_MONTH) AS prev_purchase
    FROM transactions
)
SELECT 
    CUSTOMER_ID,
    PAYMENT_MONTH,
    CASE 
        WHEN prev_purchase IS NULL THEN 'New Customer'
        WHEN DATEDIFF(month, prev_purchase, PAYMENT_MONTH) > 6 THEN 'Churned Customer'
        ELSE 'Returning Customer'
    END AS customer_status
FROM customer_activity