WITH transactions_raw AS (
    SELECT * FROM {{ source('staging', 'transactions') }}
),

cleaned_transactions AS (
    SELECT 
        CAST(customer_id AS STRING) AS customer_id,   -- Ensure it's stored as STRING
        CAST(product_id AS STRING) AS product_id,
        TRY_CAST(payment_month AS DATE) AS payment_month,  -- FIX: Converts only valid dates
        COALESCE(revenue, 0)::FLOAT AS revenue,
        COALESCE(quantity, 0)::INTEGER AS quantity,
        companies::STRING AS company
    FROM transactions_raw
    WHERE customer_id IS NOT NULL AND product_id IS NOT NULL
)

SELECT * FROM cleaned_transactions